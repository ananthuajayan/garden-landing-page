import React from "react";
import { Col, Container, Nav, Row } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
	faLinkedin,
	faTwitterSquare,
	faYoutube,
	faFacebookSquare,
	faPinterest,
	faWordpress,
} from "@fortawesome/free-brands-svg-icons";
import PropTypes from "prop-types";
import "./Footer.css"

const quickLinks = [
	{ value: "Jl,raya, kutta jay, kuta", href: "#!" },
	{ value: "Support@domain.com", href: "#!" },
	{ value: "+91 5738294", href: "#!" },
];

const socialMedia = [
	{ value: "Facebook", href: "#!" },
	{ value: "Instagram", href: "#!" },
	{ value: "LinkedIn", href: "#!" },
	{ value: "Twitter", href: "#!" },
	{ value: "LinkedIn", href: "#!" },
	{ value: "Twitter", href: "#!" },
];

const jobInfo = [
	{ value: "Select", href: "#!" },
	{ value: "Service", href: "#!" },
	{ value: "Payment", href: "#!" },
	{ value: "Select", href: "#!" },
	{ value: "Service", href: "#!" },
	{ value: "Payment", href: "#!" },
];



const sociaIcons = [
	{
		icon: faLinkedin,
		href: "#!",
	},
	{
		icon: faTwitterSquare,
		href: "#!",
	},
	{
		icon: faYoutube,
		href: "#!",
	},
	{
		icon: faFacebookSquare,
		href: "#!",
	},
	{
		icon: faPinterest,
		href: "#!",
	},
	{
		icon: faWordpress,
		href: "#!",
	},
];

const QuickLinks = ({ qLink }) => (
	<li >
		<a style={{color:"white"}} href={qLink.href}>{qLink.value}</a>
	</li>
);
QuickLinks.propTypes = {
	qLink: PropTypes.object.isRequired,
};

const SocialMedia = ({ media }) => (
	<li>
		<a style={{color:"white"}} href={media.href}>{media.value}</a>
	</li>
);
SocialMedia.propTypes = {
	media: PropTypes.object.isRequired,
};

const JobInfo = ({ job }) => (
	<li>
		<a style={{color:"white"}} href={job.href}>{job.value}</a>
	</li>
);
JobInfo.propTypes = {
	job: PropTypes.object.isRequired,
};


const CurrencyItem = ({ currency }) => (
	<option value={currency.value}>{currency.text}</option>
);
CurrencyItem.propTypes = {
	currency: PropTypes.object.isRequired,
};

const NavigationItem = ({ item }) => (
	<a className="ms-2" href={item.href}>
		{item.value}
	</a>
);

NavigationItem.propTypes = {
	item: PropTypes.object.isRequired,
};

const SocialItem = ({ social }) => (
	<li >
		<a href={social.href}>
			<FontAwesomeIcon icon={social.icon} color="yellow"/>
		</a>
	</li>
);

SocialItem.propTypes = {
	social: PropTypes.object.isRequired,
};

const Footer7 = () => {
	return (
		<section className="ezy__footer7 lights">
			<Container>
				<Row className="text-center text-sm-start">
					<Col sm={6} lg={3} className="mt-4 mt-lg-0" style={{color:"white"}}>
						<h1 style={{color:"lightgreen"}}>LO<span style={{color:"orange",fontWeight:"700"}}>GO</span></h1>
                        <p>
                            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Excepturi reprehenderit ratione, saepe sequi repellendus deserunt reiciendis
                        </p>
						<Nav className="flex-column ezy__footer7-quick-links" >
							{quickLinks.map((qLink, i) => (
								<QuickLinks qLink={qLink} key={i} />
							))}
						</Nav>
					</Col>
					<Col sm={6} lg={3} className="mt-4 mt-lg-0">
						<h5 style={{color:"white"}}>Other Pages</h5>
						<Nav className="flex-column ezy__footer7-quick-links">
							{socialMedia.map((media, i) => (
								<SocialMedia media={media} key={i} />
							))}
						</Nav>
					</Col>
					<Col sm={6} lg={3} className="mt-4 mt-lg-0">
						<h5 style={{color:"white"}}>Quick Links</h5>
						<Nav className="flex-column ezy__footer7-quick-links">
							{jobInfo.map((job, i) => (
								<JobInfo job={job} key={i} />
							))}
						</Nav>
					</Col>
					<Col sm={6} lg={3} className="mt-4 mt-lg-0">
						<h5 style={{color:"white"}}>News Letter</h5>
						<form style={{display:"flex",gap:"10px",marginBottom:"10px"}}>
                            <input type="text" placeholder="enter mail"  style={{padding:"10px",borderRadius:"5px" }}/>
                            <button style={{padding:"10px",border:"none",borderRadius:"5px",backgroundColor:"orange",color:"green"}}>Send</button>
                        </form>

                        <p style={{color:"white",marginBottom:"20px"}}>Get the latest news and updates</p>
						<Nav className="ezy__footer7-social mt-3 ali">
							{sociaIcons.map((social, i) => (
								<SocialItem social={social} key={i} />
							))}
						</Nav>
					</Col>

					<Col lg={9}>
						
						<div className="mt-3 opacity-50 ezy__footer7-copyright" >
                            <p>Brand</p>
							<span  style={{color:"white"}}>Copyright &copy; Easy Frontend, All rights reserved</span>
							{quickLinks.map((item, i) => (
								<NavigationItem item={item} key={i} />
							))}
						</div>
					</Col>
				</Row>
			</Container>
		</section>
	);
};

export default Footer7
