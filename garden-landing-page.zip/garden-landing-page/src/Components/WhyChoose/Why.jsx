import React from 'react';
import './Why.css'; 

const LandscapeService = () => {
  return (
    <div className="landscape-service-container">
      <div className="image-sections">
        <img src="https://images.pexels.com/photos/1660533/pexels-photo-1660533.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" alt="Gardener" />
      </div>
      <div className="content-section">
        <h3>Why Choose Us</h3>
        <h1>We Have The Perfect Solution For Your Landscape Problems</h1>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
          incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.
        </p>
        <div className="features">
          <div className="feature-item">
            <div className="icon">🌱</div>
            <div className="feature-text">
              <h4>Variation Gardening</h4>
              <p>
                Lorem ipsum dolor sit amet conse adipisici elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
              </p>
            </div>
          </div>
          <div className="feature-item">
            <div className="icon">🌿</div>
            <div className="feature-text">
              <h4>Expert Landscapers</h4>
              <p>
                Lorem ipsum dolor sit amet conse adipisici elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
              </p>
            </div>
          </div>
          <div className="feature-item">
            <div className="icon">💰</div>
            <div className="feature-text">
              <h4>Affordable Price</h4>
              <p>
                Lorem ipsum dolor sit amet conse adipisici elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
              </p>
            </div>
          </div>
          <div className="feature-item">
            <div className="icon">📞</div>
            <div className="feature-text">
              <h4>Free Consultation</h4>
              <p>
                Lorem ipsum dolor sit amet conse adipisici elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LandscapeService;
