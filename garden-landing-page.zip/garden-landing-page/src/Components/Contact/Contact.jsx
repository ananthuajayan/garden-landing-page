import React, { useState } from "react";
import { Button, Card, Col, Container, Form, Row } from "react-bootstrap";
import "./Contact.css"

const ContactForm = () => {
	const [validated, setValidated] = useState(false);

	const handleSubmit = (event) => {
		event.preventDefault();

		const form = event.currentTarget;
		if (form.checkValidity() === false) {
			event.preventDefault();
			event.stopPropagation();
		}

		setValidated(true);
	};

	return (
		<Form noValidate validated={validated} onSubmit={handleSubmit}>
			<Form.Group className="mb-3 mt-2">
				<Form.Control type="text" placeholder="Enter Name" />
				<Form.Control.Feedback type="valid">Message</Form.Control.Feedback>
			</Form.Group>
			<Form.Group className="mb-3 mt-2">
				<Form.Control type="email" placeholder="Enter Email" />
				<Form.Control.Feedback type="valid">Message</Form.Control.Feedback>
			</Form.Group>
			<Form.Group className="mb-3">
				<Form.Control as="textarea" rows={3} placeholder="Enter Message" />
				<Form.Control.Feedback type="valid">Message</Form.Control.Feedback>
			</Form.Group>
			<div>
				<Button variant="primary" type="submit" className="ezy__contact4-btn">
					Submit
				</Button>
			</div>
		</Form>
	);
};

const ContactFormCard = () => (
	<Card className="ezy__contact4-form-card adjust " >
		<Card.Body className="p-md-5">
			<h2 className="ezy__contact4-heading mb-3">Contact Us</h2>
			<p className="ezy__contact4-sub-heading mb-5">
				We list your menu online, help you process orders.
			</p>

			<ContactForm />
		</Card.Body>
	</Card>
);

const ContactUs4 = () => {
	return (
		<section className="ezy__contact4 light">
			<Container>
				<Row>
					<Col lg={7} className="mb-3 mb-lg-0">
						<div
							className="ezy__contact4-bg-holder h-100 "
							style={{
								backgroundImage:
									"url(https://img.freepik.com/free-photo/male-female-gardener-s-hand-wearing-gloves-planting-seedling_23-2148165360.jpg?t=st=1728442045~exp=1728445645~hmac=501411537a18b525f81679d49902d871944af0b4356f24fa9313df5909c8e83d&w=360)",
							}}
						/>
					</Col>
					<Col lg={5}>
						<ContactFormCard />
					</Col>
				</Row>
			</Container>
		</section>
	);
};

export default ContactUs4

