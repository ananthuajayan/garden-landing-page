import React from 'react';
import { motion } from 'framer-motion';
import './Services.css';

const Services = () => {
  const services = [
    {
      id: 1,
      title: 'Watering Garden',
      description: 'Lorem ipsum dolor sit amet',
      image: 'https://images.pexels.com/photos/4503261/pexels-photo-4503261.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    },
    {
      id: 2,
      title: 'Lawn Maintenance',
      description: 'Lorem ipsum dolor sit amet',
      image: 'https://images.pexels.com/photos/4503261/pexels-photo-4503261.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    },
    {
      id: 3,
      title: 'Cutting Leaf',
      description: 'Lorem ipsum dolor sit amet',
      image: 'https://images.pexels.com/photos/4503261/pexels-photo-4503261.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { type: 'spring', stiffness: 50, delayChildren: 0.2, staggerChildren: 0.3 },
    },
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  };

  return (
    <motion.div
      className="services-container"
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, amount: 0.3 }}
      variants={containerVariants}
    >
      <h3>Our Services</h3>
      <h1>Find The Best Service For Your Garden</h1>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua
      </p>
      <div className="services-cards">
        {services.map((service) => (
          <motion.div
            className="service-card"
            key={service.id}
            variants={cardVariants}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <img src={service.image} alt={service.title} />
            <div className="service-info">
              <h4>{service.title}</h4>
              <p>{service.description}</p>
              <div className="arrow">➔</div>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default Services;
