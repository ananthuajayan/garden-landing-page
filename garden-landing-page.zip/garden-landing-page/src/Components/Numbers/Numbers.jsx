import React from "react";
import { Col, Container, Row } from "react-bootstrap";
import PropTypes from "prop-types";
import "./Numbers.css"

const cards = [
	{
		number: "17",
		text: "YEARS OF EXPERIENCE",
	},
	{
		number: "1267",
		text: "SATISFIED CUSTOMERS",
	},
	{
		number: "278",
		text: "FINISHED PROJECTS",
	},
	{
		number: "355",
		text: "EMPLOYEES WORLDWIDE",
	},
];

const CardItem = ({ item }) => (
	<div>
		<h2 className="ezy__numbers12-heading mb-3">{item.number}</h2>
		<p className="ezy__numbers12-sub-heading">
			<em>{item.text}</em>
		</p>
	</div>
);

CardItem.propTypes = {
	item: PropTypes.object.isRequired,
};

const Numbers12 = () => {
	return (
		<section className="ezy__numbers12 light" >
			<div className="ezy__numbers12-overlay" />
			<Container>
				<Row className="text-center">
					{cards.map((item, i) => (
						<Col xs={12} md={6} lg={3} className="mt-4" key={i}>
							<CardItem item={item} key={i} />
						</Col>
					))}
				</Row>
			</Container>
		</section>
	);
};

export default Numbers12
