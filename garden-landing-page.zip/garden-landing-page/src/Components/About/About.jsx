import React from 'react';
import { Button } from 'react-bootstrap';
import { motion } from 'framer-motion';
import './About.css';
import { FaCheck, FaPlus } from "react-icons/fa";

const About = () => {
  const containerVariants = {
    hidden: { opacity: 0, x: -100 },
    visible: {
      opacity: 1,
      x: 0,
      transition: { type: 'spring', stiffness: 50, damping: 20, delayChildren: 0.3, staggerChildren: 0.2 },
    },
    exit: { opacity: 0, x: -100, transition: { ease: 'easeInOut' } },
  };

  const imageVariants = {
    hidden: { opacity: 0, x: -150 },
    visible: { opacity: 1, x: 0, transition: { duration: 0.5 } },
  };

  return (
    <motion.div
      className="container-fluid about-us my-5 p-4 d-flex align-items-center"
      style={{ justifyContent: "center" }}
      initial="hidden"
      whileInView="visible"
      exit="exit"
      viewport={{ once: true, amount: 0.3 }}
      variants={containerVariants}
    >
      <div className="container-md d-flex align-items-center h-100 w-100 gap-5 about">
        <motion.div className="h-100 sub" variants={containerVariants}>
          <div className="about-content">
            <p className="text-success">About Us</p>
            <h1 className="fw-bold">We Provide Landscaping And Garden Care Services</h1>
            <p className="description mt-4">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
              Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
              Duis aute irure dolor in reprehenderit.
            </p>
            <div className="features mt-4 d-flex">
              <motion.div
                style={{ height: "100%", width: "200px" }}
                className="zero-image"
                variants={imageVariants}
              >
                <img src="https://i.insider.com/626beed9c8c8ac0019410d59?width=1136&format=jpeg" alt="Service" className="img-fluid rounded" />
              </motion.div>
              <motion.div variants={containerVariants}>
                <ul className="list-unstyled">
                  <li><FaCheck color='orange' /> Public Liability Insurance</li>
                  <li><FaCheck color='orange' /> Environmentally Friendly</li>
                  <li><FaCheck color='orange' /> On Time, Every Time</li>
                  <li><FaCheck color='orange' /> Beautiful Garden Designs</li>
                  <li><FaCheck color='orange' /> Modern Machinery And Tool</li>
                  <Button className="btn-about mt-4" variant="warning">More About Us</Button>
                </ul>
              </motion.div>
            </div>
          </div>
        </motion.div>
        <motion.div
          className="image-section rounded image-section sub"
          variants={imageVariants}
        >
          <div className="small-image">
            <img src="https://images.kreatecube.com/usefull/Common/2/524.jpg" alt="hello" />
          </div>
          <div className="projects p-3 rounded">
            <div className="d-flex align-items-center gap-1">
              <h1>1,856</h1>
              <FaPlus color="yellow" />
            </div>
            <p>Projects completed</p>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default About;
