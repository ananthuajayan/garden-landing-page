import React from "react";
import { Button, Col, Container, Row } from "react-bootstrap";
import PropTypes from "prop-types";
import "./Blogs.css"

const blogs = [
	{
		title: "Nice Workplace For Brainstorming Meetings",
		description:
			"Unique side projects are the best place to innovate specially at your work.",
		author: "David Miller",
		image: "https://www.thespruce.com/thmb/LdlUEF-e9QCytFx84_sQ73VZmRE=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/vegetable-gardening-in-small-spaces-1403451-01-aa94b9199ba145079de2417b219c89b4.jpg",
		date: "26",
		month: "Oct",
		year: "2016",
	},
	{
		title: "My Adventure in Alps,The Heighest!",
		description:
			"Being creative within the constraints of client briefs, budgets and timelines.",
		author: "Shawn Paul",
		image: "https://www.thespruce.com/thmb/LdlUEF-e9QCytFx84_sQ73VZmRE=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/vegetable-gardening-in-small-spaces-1403451-01-aa94b9199ba145079de2417b219c89b4.jpg",
		date: "26",
		month: "Oct",
		year: "2019",
	},
	{
		title: "How I Escape My Mind By Listening To Music",
		description:
			"Assumenda non repellendus distinctio nihil dicta sapiente, quibusdam maiores.",
		author: "Elleca Perry",
		image: "https://www.thespruce.com/thmb/LdlUEF-e9QCytFx84_sQ73VZmRE=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/vegetable-gardening-in-small-spaces-1403451-01-aa94b9199ba145079de2417b219c89b4.jpg",
		date: "26",
		month: "Oct",
		year: "2016",
	},
];

const BlogItem = ({ blog }) => {
	return (
		<article className="ezy__blog6-post">
			<div className="position-relative">
				<img
					src={blog.image}
					alt=""
					className="img-fluid w-100 ezy-blog6-banner"
				/>
				<div className="px-4 py-3 ezy__blog6-calendar">
					{blog.date}
					<br />
					{blog.month}
					<br />
					{blog.year}
				</div>
			</div>
			<div className="p-3">
				<p className="ezy__blog6-author">
					By{" "}
					<a href="#!" className="text-decoration-none">
						{blog.author}
					</a>
				</p>
				<h4 className="mt-3 ezy__blog6-title fs-4">{blog.title}</h4>
				<p className="ezy__blog6-description mt-3 mb-4">{blog.description}</p>
				<Button variant="primary" className="ezy__blog6-btn-read-more">
					Read More
				</Button>
			</div>
		</article>
	);
};

BlogItem.propTypes = {
	blog: PropTypes.object.isRequired,
};

const Blog6 = () => {
	return (
		<section className="ezy__blog6 light">
			<Container>
				<Row className="justify-content-center">
					<Col lg={8} className="text-center">
                         <h5 style={{color:"green"}}>Blogs</h5>
						<h2 className="ezy__blog6-heading mb-3 mt-0">
							Latest News and Articlea.
						</h2>
						<p className="ezy__blog6-sub-heading px-lg-5 mb-4">
							Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras eu
							ex et nisi condimentum viverra. Integer maximus, neque sed
							placerat congue.
						</p>
					</Col>
				</Row>
				<Row className="mt-5">
					{blogs.map((blog, i) => (
						<Col xs={12} md={6} lg={4} className="mb-3" key={i}>
							<BlogItem blog={blog} />
						</Col>
					))}
				</Row>

			</Container>
		</section>
	);
};

export default Blog6