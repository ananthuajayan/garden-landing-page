import React from 'react';
import { Button, Container, Row, Col } from 'react-bootstrap';
import './Main.css';

const LandingPage = () => {
  return (
    <div className="landing-page">
      <div className="overlay">
        <Container className="content-container">
          <Row>
            <Col md={6}>
              <div className="content-box p-4">
                <h1 className="heading">
                  Complete For All <span className="highlight">Landscape</span> Service And Maintenance
                </h1>
                <p className="description">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim exercitation.
                </p>
                <div className="buttons mt-3">
                  <Button className="btn-contact" variant="warning" size="lg">Contact Us</Button>
                  <Button className="btn-watch ms-3" variant="outline-dark" size="lg">Watch Intro</Button>
                </div>
              </div>
            </Col>
          </Row>
        </Container>
      </div>
    </div>
  );
};

export default LandingPage;
