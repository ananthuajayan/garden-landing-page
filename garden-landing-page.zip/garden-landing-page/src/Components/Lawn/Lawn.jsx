import React from 'react'
import "./Lawn.css"

const Lawn = () => {
  return (
    <div className="container-fluid lawn">
        <div className="overlay"></div>
        <div className='adjust-margin'>
        <h3 style={{color:"orange"}}>Our Services</h3>
      <h1 style={{fontWeight:"700",color:"white"}}>Find The Best Service For Your Garden</h1>
      <p style={{color:"white"}}>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua
      </p>
        </div>
       
    </div>
  )
}

export default Lawn