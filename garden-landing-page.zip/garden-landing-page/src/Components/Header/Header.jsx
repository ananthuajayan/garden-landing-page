import React, { useState } from "react";
import "./Header.css";
import {
	Container,
	Nav,
	Navbar,
} from "react-bootstrap";
import { CiLocationOn } from "react-icons/ci";
import { FaTwitter,FaYoutube,FaInstagram } from "react-icons/fa";
import classNames from "classnames";
import PropTypes from "prop-types";

const routes = [
	{ name: "Home", href: "#" },
	{ name: "About Us", href: "#" },
	{ name: "Services", href: "#" },
	{ name: "Pages", href: "#" },
	{ name: "Blog", href: "#" },
	{ name: "Contact", href: "#" },
];

const NavMenu = ({ routes, children }) => (
	<Nav className="mb-2 mb-lg-0 mt-4 mt-lg-0 d-flex gap-5">
		{routes.map((route, i) => (
			<Nav.Item key={i}>
				<Nav.Link href={route.href}>{route.name}</Nav.Link>
			</Nav.Item>
		))}
		{children}
	</Nav>
);

NavMenu.propTypes = {
	routes: PropTypes.array.isRequired,
	children: PropTypes.node,
};

const LocationIcon = () => (
	<Nav.Item className="mb-2 mb-lg-0 d-flex justify-content-center align-items-center gap-2">
		<div 
			className="d-flex justify-content-center align-items-center bg-success rounded-circle"
			style={{ width: '50px', height: '50px' }}
		>
			<CiLocationOn color="yellow" size={30} />
		</div> 
		<div className="d-flex justify-content-center flex-column">
			<h5 className="fw-bold">Location</h5>
			<p style={{ color: "lightgray" }}>Jl No 10 kutta no kuta</p>
		</div>
	</Nav.Item>
);
const ContactIcon = () => (
	<Nav.Item className="mb-2 mb-lg-0 d-flex justify-content-center align-items-center gap-2">
		<div 
			className="d-flex justify-content-center align-items-center bg-success rounded-circle"
			style={{ width: '50px', height: '50px' }}
		>
			<CiLocationOn color="yellow" size={30} />
		</div> 
		<div className="d-flex justify-content-center flex-column">
			<h5 className="fw-bold">Location</h5>
			<p style={{ color: "lightgray" }}>Jl No 10 kutta no kuta</p>
		</div>
	</Nav.Item>
);
const Payment = () => (
	<Nav.Item className="mb-2 mb-lg-0 d-flex justify-content-center align-items-center gap-2">
		<button id="payment-button">
           Make a payment
        </button>
	</Nav.Item>
);

const NavMenu2 = () => (
	<Nav className="mx-auto mb-2 mb-lg-0 mt-4 mt-lg-0 d-flex gap-2">
		<div className="d-flex align-items-center border-end pe-2">
        <LocationIcon />
      </div>
      <div className="d-flex align-items-center border-end pe-2">
        <ContactIcon />
      </div>
      <div className="d-flex align-items-center zoro">
        <Payment />
      </div>
	</Nav>
);

const NavMenu3 = () => (
	<Nav className="ezy__nav1-navbar-nav flex-row ms-auto d-flex gap-1 ">
		<Nav.Item>
       <div className="d-flex justify-content-center align-items-center bg-success rounded-circle"
			style={{ width: '40px', height: '40px' }}
		>
			<CiLocationOn color="yellow" size={25} />
		</div> 
		</Nav.Item>
		<Nav.Item>
       <div className="d-flex justify-content-center align-items-center bg-success rounded-circle"
			style={{ width: '40px', height: '40px' }}
		>
			<FaTwitter color="yellow" size={25} />
		</div> 
		</Nav.Item>
		<Nav.Item>
       <div className="d-flex justify-content-center align-items-center bg-success rounded-circle"
			style={{ width: '40px', height: '40px' }}
		>
			<FaYoutube color="yellow" size={25} />
		</div> 
		</Nav.Item>
		<Nav.Item>
       <div className="d-flex justify-content-center align-items-center bg-success rounded-circle"
			style={{ width: '40px', height: '40px' }}
		>
			<FaInstagram  color="yellow" size={25} />
		</div> 
		</Nav.Item>
	</Nav>
);


const Header = () => {
	const [isOpenSearch, setIsOpenSearch] = useState(false);

	const toggleSearch = () => setIsOpenSearch(!isOpenSearch);

	return (
		<div className="ezy__nav6 light">
			<Navbar expand="lg" className="flex-column py-3">
				<Container>
					<Navbar.Brand href="#" style={{color:"green"}}>LO<span style={{color:"orange"}}>GO</span></Navbar.Brand>
					<Navbar.Toggle
						className={classNames("navbar-toggler", {
							collapsed: !isOpenSearch,
						})}
						onClick={toggleSearch}
						aria-controls="ezy__nav6-navbar-nav-2"
					/>
					<Navbar.Collapse in={isOpenSearch} id="ezy__nav6-navbar-nav-2">
						<NavMenu2 />
					</Navbar.Collapse>
				</Container>
				<hr className="w-100 ezy__nav1-separator" />
				<div className="w-100">
					<Container className="d-flex">
						<Navbar.Toggle aria-controls="ezy__nav6-navbar-nav">
							<span>
								<span />
							</span>
						</Navbar.Toggle>
						<Navbar.Collapse id="ezy__nav6-navbar-nav">
							<NavMenu routes={routes} />
						</Navbar.Collapse>
						<NavMenu3 />
					</Container>
				</div>
			</Navbar>
		</div>
	);
};

export default Header;
 