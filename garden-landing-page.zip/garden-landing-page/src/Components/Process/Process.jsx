import React from 'react';
import './Process.css'; 

const WorkProcess = () => {
  const steps = [
    {
      id: 1,
      title: 'Start Consultation',
      icon: '🗣️', 
      stepNumber: '01',
    },
    {
      id: 2,
      title: 'Design Installation',
      icon: '🛠️', 
      stepNumber: '02',
    },
    {
      id: 3,
      title: 'Start Construction',
      icon: '👷',
      stepNumber: '03',
    },
    {
      id: 4,
      title: 'Finished Work',
      icon: '🌿',
      stepNumber: '04',
    },
  ];

  return (
    <div className="work-process-container">
      <h3>Work Process</h3>
      <h1>We Complete Every Step Carefully</h1>
      <p>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua
      </p>
      <div className="work-steps">
        {steps.map((step) => (
          <div className="work-step-card" key={step.id}>
            <div className="step-icon">{step.icon}</div>
            <h4>{step.title}</h4>
            <div className="step-number">{step.stepNumber}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default WorkProcess;
