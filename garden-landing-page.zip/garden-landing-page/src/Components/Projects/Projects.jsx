import React from 'react';
import './Projects.css'; 

const Projects = () => {
  const services = [
    {
      id: 1,
      title: 'Watering Garden',
      description: 'Lorem ipsum dolor sit amet',
      image: 'https://images.pexels.com/photos/4503261/pexels-photo-4503261.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', 
    },
    {
      id: 2,
      title: 'Lawn Maintenance',
      description: 'Lorem ipsum dolor sit amet',
      image: 'https://images.pexels.com/photos/4503261/pexels-photo-4503261.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', 
    },
    {
      id: 3,
      title: 'Cutting Leaf',
      description: 'Lorem ipsum dolor sit amet',
      image: 'https://images.pexels.com/photos/4503261/pexels-photo-4503261.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1', 
    },
  ];

  return (
    <div className="services-container mt-5">
        <div className="pro mb-5">
            <div>
            <h3>Our Projects</h3>
            <h1>Projects we have done</h1>
            </div>
       
      <p className='para'>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua
      </p>

      <button style={{padding:"10px",backgroundColor:"yellow",borderRadius:"10px",border:"none"}}>All projects</button>
        </div>
     
      <div className="services-cards">
        {services.map((service) => (
          <div className="service-card" key={service.id}>
            <img src={service.image} alt={service.title} />
            <div className="service-info">
              <h4>{service.title}</h4>
              <p>{service.description}</p>
              <div className="arrow">➔</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Projects;
