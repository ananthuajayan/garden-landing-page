import './App.css';
import Header from './Components/Header/Header';
import LandingPage from './Components/mainHeader/Mainhead';
import About from './Components/About/About';
import LandscapeService from './Components/WhyChoose/Why';
import Services from './Components/Services/Services';
import Lawn from './Components/Lawn/Lawn';
import Process from './Components/Process/Process'
import ContactForm from './Components/Contact/Contact';
import Numbers from './Components/Numbers/Numbers'
import Projects from './Components/Projects/Projects';
import Blog6 from './Components/Blogs/Blogs';
import Footer7 from './Components/Footer/Footer';


function App() {
  return (
    <>
    <div className="container-fluid">
      <div className="container-md">
      <Header/>
      </div>
    </div>
        <LandingPage/>
        <About/>
        <LandscapeService/>
        <Services/>
        <Lawn/>
        <ContactForm/>
        <Process/>
        <Numbers/> 
        <Projects/>
        <Blog6/>  
        <Footer7/>
    </>
  );
}

export default App;
